package Main;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;

import jdbm.helper.FastIterator;

public class main {
	public static void main(String[] args){  
		try{
			//link to db--ht1,handle word database
			InvertedIndex indexht2 = new InvertedIndex("4321phase1","ht2");
			FastIterator iterht2 = indexht2.getKeys();
			String keyht2;
			keyht2=(String)iterht2.next();
			while(keyht2!=null){
				Doc tempDoc=(Doc)indexht2.getHashtable(keyht2);
				System.out.println(tempDoc.title);
				System.out.println(keyht2);
				System.out.println(tempDoc.lastModifiedDate+","+tempDoc.size);
				try{
					InvertedIndex indexht1 = new InvertedIndex("4321phase1","ht1");
					FastIterator iterht1 = indexht1.getKeys();
					String keyht1;
					keyht1=(String)iterht1.next();
					while(keyht1!=null){
						ArrayList<Content> tempContentList=(ArrayList<Content>)indexht1.getHashtable(keyht1);
						for(int a=0;a<tempContentList.size();a++){
//							System.out.print("web1:"+tempContentList.get(a).docURL+"\n"+"web2:"+keyht2+"\n");
							if(tempContentList.get(a).docURL.equals(keyht2)){
								System.out.print(keyht1+" "+tempContentList.get(a).location.size()+"; ");
							}
						}
						keyht1=(String)iterht1.next();
					}
					System.out.print("\n\n");
					for(int a=0;a<tempDoc.childLink.size();a++){
						System.out.println(tempDoc.childLink.get(a));
					}
					indexht1.finalize();
				}
				catch(IOException ex)
				{
					System.err.println(ex.toString());
				}
				keyht2=(String)iterht2.next();
				System.out.println("-------------------------------------------------------------------------------------------");
			}
			indexht2.finalize();
		}
		catch(IOException ex)
		{
			System.err.println(ex.toString());
		}
	}
}
